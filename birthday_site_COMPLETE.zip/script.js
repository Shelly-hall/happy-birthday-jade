function createBalloons() {
  const music = document.getElementById('birthdayMusic');
  music.play();
  for (let i = 0; i < 25; i++) {
    let balloon = document.createElement('div');
    balloon.className = 'balloon';
    balloon.style.backgroundColor = `hsl(${Math.random() * 360}, 100%, 75%)`;
    balloon.style.left = `${Math.random() * 100}vw`;
    balloon.style.animationDuration = `${6 + Math.random() * 3}s`;
    document.body.appendChild(balloon);
  }
  setTimeout(showMessage, 9000);
}

function startCelebration() {
  createBalloons();
  document.querySelector('.button').style.display = 'none';
}

function showMessage() {
  const msg = document.getElementById('message');
  const paragraphs = [
    "Jade, on this day I want to wish you the happiest of happiest birthdays. May God continue to guide and protect you. I hope your week, today, and the rest of your week has been or will be filled with nothing but love, laughter, and joy.❤",
    "It still feels surreal how someone I knew nothing about a year ago has become one of my favorite people... no, my favorite person. I already gave you a book about my feelings, so there's no need for me to say all that again... So I'll keep it short.",
    "I love you, Jade. I'm glad that I was persistent in getting you to talk to me, because if I wasn't, we would probably not be here right now. I'm thankful for all the minutes of the days I get to spend with you... even if all we do is sit in silence, it means the world to me... You mean the world to me. Your smile, your laughter, your presence, everything about you from the way you talk to the way you walk is a reminder of the beauty and joy that you bring to my life. You're like that pot of gold at the end of a rainbow... Your presence is a gift, and I am grateful to have received it. I hope you stay in my life, and I also hope that you allow me to stay in yours. Cheers to you Pretty, on turning 18🥂 And a Happy birthday to you again 🥳❤"
  ];

  paragraphs.forEach((paragraph, index) => {
    let p = document.createElement('p');
    p.innerHTML = paragraph;
    setTimeout(() => {
      p.style.opacity = 1;
      msg.appendChild(p);
    }, index * 2000);
  });
}